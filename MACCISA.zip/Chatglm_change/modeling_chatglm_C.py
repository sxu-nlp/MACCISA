def chat(self, tokenizer, query: str, history: List[Tuple[str, str]] = None, max_length: int = 2048, num_beams=1,
         do_sample=True, top_p=0.7, temperature=0.95, logits_processor=None, **kwargs):
    if history is None:
        history = []
    if logits_processor is None:
        logits_processor = LogitsProcessorList()
    logits_processor.append(InvalidScoreLogitsProcessor())
    gen_kwargs = {"max_length": max_length, "num_beams": num_beams, "do_sample": do_sample, "top_p": top_p,
                  "temperature": temperature, "logits_processor": logits_processor, **kwargs}
    if not history:
        prompt = query
    else:
        prompt = ""
        for i, (old_query, response) in enumerate(history):
            prompt += "[Round {}]\n问：{}\n答：{}\n".format(i, old_query, response)
        prompt += "[Round {}]\n问：{}\n答：".format(len(history), query)
    inputs = tokenizer([prompt], return_tensors="pt")
    inputs = inputs.to(self.device)
    outputs = self.generate(**inputs, **gen_kwargs)
    out = []
    for i in range(len(outputs)):
        out.append(list(outputs[i]))
    ans = out[0][28]
    for i in range(1, len(out)):
        ans = torch.cat((ans, out[i][28]))
    # print(ans.shape)
    ans = torch.squeeze(ans, dim=1)
    # print(ans.shape)
    # print(outputs)
    # outputs = outputs.tolist()[0][len(inputs["input_ids"][0]):]
    # response = tokenizer.decode(outputs)
    # response = self.process_response(response)
    # history = history + [(query, response)]
    # return response, history
    return ans